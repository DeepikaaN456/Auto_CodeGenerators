# Performance notes


TODO: write a real page

*   should perform like a hand-written class after HotSpot compiles it
    (generated accessors can be inlined)
*   what does proguard do with it
*   hash codes are not cached
