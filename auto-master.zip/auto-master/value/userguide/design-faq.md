# Design FAQ


TODO. This page will contain various explanations of *why* AutoValue's features
were designed as they are.
